<html>
<body>
Test3

<h1>Contact List</h1>


   <link rel="stylesheet" href="styles.css">

<table style="width: 80%" border="1">
	<tr>
		<th>S#</th>
		<th>Name</th>
		<th>Profession</th>
		<th>Telephone Number</th>
		<th>Mobile Number</th>
		<th>address</th>
		<th>Operations</th>
	</tr>

	<?php
	// set your infomation.
	$host		=	'localhost';
	$user		=	'root';
	$pass		=	'';	
	$database	=	'contacts';
	
	
	// connect to the mysql database server.
	$connect = @mysql_connect ( $host, $user, $pass ) ;
		if ( $connect )
	{
		mysql_select_db ( $database, $connect );
		$sql = "select * from person";
		
		if ( @mysql_query ( $sql) ){
			$i=1;
			$query = mysql_query ( $sql );
			$row = mysql_fetch_assoc ( $query );
			do {
				?>
				<tr>
				<td><?php echo $i++; ?></td>
				<td><?php echo $row['contact_name']; ?></td>
				<td><?php echo $row['contact_profession']; ?></td>
				<td><?php echo $row['contact_Tel_number']; ?></td>
				<td><?php echo $row['contact_mobile_number']; ?></td>
				<td><?php echo $row['address']; ?></td>
				<td>
					<a href="Update.php?id=<?php echo $row['contact_mobile_number'] ?>&nm=<?php echo $row['contact_name'] ?>&pr=<?php echo $row['contact_profession'] ?>&tel=<?php echo $row['contact_Tel_number'] ?>&ad=<?php echo $row['contact_name'] ?>">Update</a>
					<a href="delete.php?id=<?php echo $row['contact_mobile_number'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
				</td>
			</tr>
<?php
			} while ( $row = mysql_fetch_assoc ( $query ) );
?>
	
	<?php
			
		}
		else {
				die ( mysql_error() );
		}	
	}
	else {
		trigger_error ( mysql_error(), E_USER_ERROR );
	}
	?>


</body>
</html>