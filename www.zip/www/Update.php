<html>
<body>

<?php

	// set your infomation.
	$host		=	'localhost';
	$user		=	'root';
	$pass		=	'';	
	$database	=	'contacts';
	
	
	// connect to the mysql database server.
	$connect = @mysql_connect ( $host, $user, $pass ) ;

	if ( $connect )
	{
		mysql_select_db ( $database, $connect );

		$id = $_GET['id'];
		$nm = $_GET['nm'];
		$pr = $_GET['pr'];
		$tel = $_GET['tel'];
		$ad = $_GET['ad'];
	
	        
	}
	

        
			
?>
<h1>Update Person's Phone number and Name
</h1>

<form action="" method="GET">
Name: <input type="text" value="<?php echo "$nm"?>" name="contact_name" />
Profession: <input type="text" value="<?php echo "$pr"?>" name="contact_profession" /><br>
Telephone Number: <input type="text" value="<?php echo "$tel"?>" name="contact_Tel_number" /><br>
Mobile Number: <input type="text" value="<?php echo "$id"?>" name="contact_mobile_number" /><br>
Address: <input type="text" value="<?php echo "$ad"?>" name="address" /><br>
<input type="submit" />
<input type="reset">
</form>

</body>
</html>
<?php

	// set your infomation.
	$host		=	'localhost';
	$user		=	'root';
	$pass		=	'';	
	$database	=	'contacts';
	
	
	// connect to the mysql database server.
	$connect = @mysql_connect ( $host, $user, $pass ) ;

	if ( $connect )
	{
		mysql_select_db ( $database, $connect );

			$rollno = $_GET['id'];
			$contact_name = $_GET['contact_name'];
			$contact_profession = $_GET['contact_profession'];
			$contact_Tel_number = $_GET['contact_Tel_number'];
			$contact_mobile_number = $_GET['contact_mobile_number'];
			$address = $_GET['address'];

		$query = "UPDATE person SET contact_name='$contact_name', contact_profession='$contact_profession', contact_Tel_number='$contact_Tel_number', contact_mobile_number='$contact_mobile_number', address='$address' WHERE contact_mobile_number='$rollno'";

			if ( @mysql_query ( $query ) )
			{
				echo 'Record Updated Successfullt';
			}
			else {
				die ( mysql_error() );
			}	
	        
	}
	else {
		trigger_error ( mysql_error(), E_USER_ERROR );
	}




	
	     
	

        
			
?>

