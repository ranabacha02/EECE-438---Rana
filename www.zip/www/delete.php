<?php

	$host	    = 	'localhost';
	$user		=	'root';
	$pass		=	'';	
	$database	=	'contacts';

// Create connection
$conn = new mysqli($host, $user, $pass, $database);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// sql to delete a record
$rollno = $_GET['id'];
$query = "DELETE FROM person WHERE contact_mobile_number= '$rollno'";


if (mysqli_query($conn, $query)) {

  echo "Record deleted successfully";

} else {
  echo "Error deleting record: " . mysqli_error($conn);
}

mysqli_close($conn);
?>