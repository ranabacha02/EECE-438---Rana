<html>
<body>
<?php
echo("Thank you for rating my website " . $_SERVER['HTTP_REFERER'] . " with "  . $_POST['rating']);
?>
</bofy>
</html>