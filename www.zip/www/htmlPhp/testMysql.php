<?php
$koneksi = mysql_connect('localhost','root','Laila+-2019');

$checkmysqlserver = mysql_query('show processlist');

$b = 0;
$c = mysql_num_fields($checkmysqlserver);

do {
$data = mysql_fetch_row($checkmysqlserver);

print ( $data[0] . $data[1] . $data[2] .
$data[3] . $data[4] . $data[5] .
$data[6] . $data[7] );

$b++;
}while($b < $c);
?>