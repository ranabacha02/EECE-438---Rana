
<html>


<title>
My First PHP example
</title>

</head>

<body>
<?php

print(Date("<p>l F d, Y </p>"));
$total_ratings = (3+2+3+1+5+2+3);

$total_votes = 7;
$average = $total_ratings / $total_votes;
print("<p>The Average Rating Is: $average </p>");
?>
</body>

</html>
