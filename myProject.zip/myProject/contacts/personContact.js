const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const Person = mongoose.model('Person');

router.get('/',(req,res)=>{
	res.render("person/addOrEdit", {viewTitle : "Insert Contact"});
});

router.post('/',(req,res)=>{
	if(req.body._id=='')
		insertRecord(req,res);
		else
			updateRecord(req,res);
});

//Insert
function insertRecord(req,res){
	var person = new Person();
	person.contact_name= req.body.contact_name;
	person.contact_profession = req.body.contact_profession;
	person.contact_mobile_number = req.body.contact_mobile_number;
	person.contact_tel_number = req.body.contact_tel_number;
	person.address = req.body.address;
	person.save((err,doc) =>{
		if (!err)
			res.redirect('person/list');
		else{
			if(err.contact_name == 'ValidationError'){
				handleValidationError(err,req.body);
				res.render("person/addOrEdit",{
					viewTitle: "Insert Contact",
					person : req.body
				});
			}
			else
			console.log('Error during record insertion : ' + err);
		}
	});
}

//Update
function updateRecord(req,res){
	Person.findOneAndUpdate({_id: req.body._id}, req.body, {new : true}, (err,doc) => {
		if (!err){ res.redirect('person/list');}
		else{
			if(err.name == 'ValidationError'){
				handleValidationError(err, req.body);
				res.render("person/addOrEdit", {
					viewTitle:"Update Person",
					person: req.body
				});
			}
			else
				console.log('Error during record update:' +err);
		}
	});
}

//display
router.get('/list', (req,res) => {
	Person.find((err, docs) => {
		if (!err){
			res.render("person/list", {
				list: docs
			});
		}
		else{
			console.log('Error in retrieveing person List: '+ err);
		}
	}).lean();
});

function handleValidationError(err,body){
	for(field in err.errors)
	{
		switch(err.errors[field].path){
			case 'contact_name':
				body['contact_nameError']=err.errors[field].message;
				break;
			default:
			break;

		}
	}
}


//Get person by id
router.get('/:id', (req,res) => {
	Person.findById(req.params.id, (err,doc) =>{
		if(!err){
			res.render("person/addOrEdit", {viewTitle : 'Update Contact', person:doc});
			person: doc
		}
		else{console.log('Error in person update:' + err);}
	}).lean();
});


//Delete Person
router.get('/delete/:id', (req,res) => {
	Person.findByIdAndRemove(req.params.id, (err,doc) =>{
		if(!err){
			res.redirect('/person/list');
		}
		else{console.log('Error in person delete:' + err);}
	});
});

module.exports=router;