const mongoose = require ('mongoose');

var personSchema = new mongoose.Schema({
	contact_name: {
		type:String,
		required: 'This field is required.'
	},
	contact_profession:{
		type:String
	},
	contact_mobile_number:{
		type:String
	},
	contact_tel_number:{
		type:String
	},
	address:{
		type:String
	}

});


mongoose.model('Person', personSchema);