require('./models/db');

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const exphbs = require('express-handlebars');

const personContact = require('./contacts/personContact');

var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


app.set('views', path.join(__dirname, '/views/'));
app.engine('hbs', exphbs.engine({extname: 'hbs', defaultLayout: 'mainLayout', LayoutsDir: __dirname + '/views/layouts/'}));
app.set('view engine', 'hbs');

const port = 3000;


app.use('/person', personContact);

app.use(cors());

app.listen(port, () => console.log(`Hello world app listening on port ${port}!`));

